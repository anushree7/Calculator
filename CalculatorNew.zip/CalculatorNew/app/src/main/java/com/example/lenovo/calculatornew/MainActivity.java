package com.example.lenovo.calculatornew;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText n;
    Button b1;
    Button b2;
    Button b3;
    Button b4;
    Button b5;
    Button b6;
    Button b7;
    Button b8;
    Button b9;
    Button b0;
    Button bdot;
    Button beql;
    Button bpls;
    Button bmins;
    Button bmul;
    Button bdiv;
    Button bclr;
    float v1;
    float v2;
    float v;
    boolean add,min,mul,div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        n=(EditText)findViewById(R.id.Etnum);
        b1=(Button)findViewById(R.id.btn1);
        b2=(Button)findViewById(R.id.btn2);
        b3=(Button)findViewById(R.id.btn3);
        b4=(Button)findViewById(R.id.btn4);
        b5=(Button)findViewById(R.id.btn5);
        b6=(Button)findViewById(R.id.btn6);
        b7=(Button)findViewById(R.id.btn7);
        b8=(Button)findViewById(R.id.btn8);
        b9=(Button)findViewById(R.id.btn9);
        b0=(Button)findViewById(R.id.btn0);
        beql=(Button)findViewById(R.id.btnequal);
        bdot=(Button)findViewById(R.id.btnpoint);
        bpls=(Button)findViewById(R.id.btnplus);
        bmins=(Button)findViewById(R.id.btnminus);
        bmul=(Button)findViewById(R.id.btnmul);
        bdiv=(Button)findViewById(R.id.btndiv);
        bclr=(Button)findViewById(R.id.btnclr);

        n.setText(" ");
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"1");
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"2");
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"3");
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"5");
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"5");
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"6");
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"7");
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"8");
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"9");
            }
        });
        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+"0");
            }
        });
        bdot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText(n.getText()+".");
            }
        });
        bpls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                v1=Float.valueOf(n.getText().toString());
                n.setText(n.getText()+"+");
                add=true;
            }
        });
        bmins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                v1=Float.valueOf(n.getText().toString());
                n.setText(n.getText()+"-");
                min=true;
            }
        });
        bmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                v1=Float.valueOf(n.getText().toString());
                n.setText(n.getText()+"*");
                mul=true;
            }
        });
        bdiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                v1=Float.valueOf(n.getText().toString());
                n.setText(n.getText()+"*");
                div=true;
            }
        });

        bclr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText("");
            }
        });
        beql.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(add)
                {
                    String str=n.getText().toString();
                    String[] nstr=str.split("\\+");
                    v2=Float.parseFloat(nstr[1]);
                    v=v1+v2;
                    String ne=Float.toString(v);
                    n.setText(n.getText()+"="+ne);


                }
                else if(min)
                {
                    String str=n.getText().toString();
                    String[] nstr=str.split("-");
                    v2=Float.parseFloat(nstr[1]);
                    v=v1-v2;
                    String ne=Float.toString(v);
                    n.setText(n.getText()+"="+ne);
                }
                else if(mul)
                {
                    String str=n.getText().toString();
                    String[] nstr=str.split("\\*");
                    v2=Float.parseFloat(nstr[1]);
                    v=v1*v2;
                    String ne=Float.toString(v);
                    n.setText(n.getText()+"="+ne);
                }
                else if(div)
                {
                    String str=n.getText().toString();
                    String[] nstr=str.split("/");
                    v2=Float.parseFloat(nstr[1]);
                    v=v1/v2;
                    String ne=Float.toString(v);
                    n.setText(n.getText()+"="+ne);
                }
                else
                {
                    n.setText(n.getText()+"=");
                }
            }
        });
    }
}
